import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const base = path.dirname(__filename);

if (!fs.existsSync(publicDir)) fs.mkdirSync(publicDir);
if (!fs.existsSync(extraDir)) fs.mkdirSync(extraDir);

const publicFiles = [
    'index.html', 'admin.html', 'employee.html', 'user.html', 'register.html',
    'styles.css', 'app.js', 'manifest.json', 'sw.js', 'icons'
];

const extraFiles = [
    'test_db.js', 'test_get.js', 'test_node.js', 'test_reg.js', 'test_security.js',
    'binary_copy.js', 'copy_icons.js', 'copy_pwa_icons.js', 'write_pngs.js',
    'debug.js', 'runner.js', 'pwa_setup.bat', '{', 'server_log.txt'
];

publicFiles.forEach(f => {
    const src = path.join(base, f);
    const dest = path.join(publicDir, f);
    if (fs.existsSync(src)) {
        console.log(`Moving ${f} -> public`);
        fs.renameSync(src, dest);
    }
});

extraFiles.forEach(f => {
    const src = path.join(base, f);
    const dest = path.join(extraDir, f);
    if (fs.existsSync(src)) {
        console.log(`Moving ${f} -> extra_scripts`);
        fs.renameSync(src, dest);
    }
});

console.log('Files moved successfully.');
