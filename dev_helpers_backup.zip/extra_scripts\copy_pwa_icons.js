const fs = require('fs');
const path = require('path');

const srcIconPath = 'C:\\Users\\revin\\.gemini\\antigravity\\brain\\09a1cac5-80da-4d9a-82ad-a83648b9c570\\app_icon_512_1774602914489.png';
const destIcon512 = path.join(__dirname, 'icons', 'icon-512.png');
const destIcon192 = path.join(__dirname, 'icons', 'icon-192.png');

try {
    if (fs.existsSync(srcIconPath)) {
        fs.copyFileSync(srcIconPath, destIcon512);
        fs.copyFileSync(srcIconPath, destIcon192); // Normally resize, but using 512 for both works
        console.log('Successfully copied PNG icons for PWA.');
    } else {
        console.error('Source icon not found:', srcIconPath);
    }
} catch(err) {
    console.error('Failed to copy icons:', err);
}
