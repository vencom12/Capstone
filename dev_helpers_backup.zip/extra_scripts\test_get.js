const http = require('http');
const fs = require('fs');

http.get('http://localhost:5000/api/products', (res) => {
    let data = '';
    res.on('data', (chunk) => data += chunk);
    res.on('end', () => {
        fs.writeFileSync('output.txt', `Status: ${res.statusCode}\n${data}`);
    });
}).on('error', (err) => {
    fs.writeFileSync('output.txt', `Error: ${err.message}`);
});
