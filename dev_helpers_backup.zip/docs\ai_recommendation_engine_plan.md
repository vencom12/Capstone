# AI Feature Plan: AI Recommendation Engine (Virtual Store Attendant)

## Goal
To provide a personalized shopping experience by acting as a virtual assistant that helps customers find the perfect design based on their needs, style, and history.

## Specific Goals
1. **Interactive Guided Shopping**: A chat interface where customers can say "I need a gift for a graduation" and receive tailored suggestions.
2. **Preference Learning**: Track which categories or colors a customer views most to prioritize those in the "Recommendations" section.
3. **Smart Cross-Selling**: Suggest matching designs (e.g., "This cap design goes perfectly with the shirt you just viewed").
4. **Natural Language Search**: Allow customers to find products using descriptions like "something blue and floral" instead of exact names.

---

## Technical Flow

### 1. The "Attendant" Chatbot
- A floating chat bubble on the storefront (`index.html`).
- Uses a text-based LLM (e.g., Groq/Llama-3) with a "System Prompt" defining it as a helpful Stitch-Opt store attendant.
- The AI has access to a summarized list of all current products and their `tags`.

### 2. Matching Logic
- When a user chats or browses, the system updates a `UserPreference` JSON in the database.
- The AI uses this JSON to filter the `prisma.product.findMany()` results.

### 3. UI/UX Interaction
- Instead of just text, the AI can "push" product cards directly into the chat window.
- Customers can click "Add to Basket" directly from the AI's suggestion.

---

## Instructions for Implementation
1. **Storefront Integration**: Build the `AI-Attendant` component in `public/legacy/js/customer.js`.
2. **Context Injection**: Ensure the LLM always receives the latest product catalog as part of its "knowledge" during a session.
3. **Basket Integration**: Connect the Chat UI to the existing `addToBasket()` function in the storefront.
