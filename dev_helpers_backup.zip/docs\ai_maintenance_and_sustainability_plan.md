# AI Feature Plan: AI Maintenance & Sustainability (No-Code Config)

## Goal
To ensure the system remains functional even after the original developers hand over the project, by allowing Admins to update AI models and API keys through a user-friendly dashboard interface.

## Specific Goals
1. **Dynamic Model Swapping**: Allow Admins to change the active AI model (e.g., from `llama-3.2` to `llama-4.0`) via the UI.
2. **API Key Management**: Provide a secure way to update API keys without editing the `.env` file or source code.
3. **Threshold Control**: Allow Admins to adjust AI "Confidence Scores" (how strictly the AI verifies payments).
4. **Provider Flexibility**: Architect the system to easily switch between providers (Groq, OpenAI, Anthropic) using standardized settings.

---

## Technical Flow

### 1. Database Configuration Table
- **Model**: `SystemSetting`
- **Fields**: `id`, `key` (String, Unique), `value` (String), `category` (e.g., "AI", "Business").
- **Seeded Keys**: 
    - `AI_QUEUE_MODEL`
    - `AI_VISION_MODEL`
    - `AI_FORECAST_MODEL`
    - `AI_PROVIDER_URL`

### 2. The Dynamic Backend Fetch
- In `aiController.js`, instead of hardcoding:
  `const model = "llama-3.2-vision-11b";`
- Use:
  `const config = await prisma.systemSetting.findUnique({ where: { key: 'AI_VISION_MODEL' } });`
  `const model = config.value;`

### 3. Admin UI (Settings Tab)
- **AI Configuration Panel**: A table listing all AI keys and their current values.
- **Validation**: When the Admin clicks "Save," the system runs a quick "Health Check" (a ping to the AI API) to ensure the new model/key works before committing the change.

---

## Instructions for Implementation
1. **Prisma Update**: Add the `SystemSetting` model to `schema.prisma`.
2. **CRUD Controller**: Create `controllers/postgres/settingsController.js` to manage these keys.
3. **Admin Page**: Add a sub-section in the Admin "Settings" sidebar specifically for "AI Intelligence Setup."
4. **Handoff Documentation**: Ensure the final user manual includes a list of valid model strings for major providers.
