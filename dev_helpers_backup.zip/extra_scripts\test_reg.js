const fetch = require('node-fetch');

async function testRegister() {
    try {
        const response = await fetch('http://localhost:5000/api/auth/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: 'testuser', email: 'test@test.com', password: 'password', role: 'customer' })
        });
        const data = await response.text();
        console.log("Status:", response.status);
        console.log("Response:", data);
    } catch (err) {
        console.error("Error:", err.message);
    }
}

testRegister();
