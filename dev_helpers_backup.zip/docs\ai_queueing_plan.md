# AI Feature Plan: Intelligent Queueing System

## Goal
To replace the standard FIFO (First-In-First-Out) order processing with a dynamic, priority-weighted queue that optimizes production efficiency and meets critical deadlines.

## Specific Goals
1. **Dynamic Priority Scoring**: Automatically calculate a score (0-100) for every order.
2. **Deadline Management**: Ensure orders with approaching delivery dates automatically move up.
3. **Rush Processing**: Instantly prioritize "Rush" orders while balancing the existing workload.
4. **Real-time Re-ordering**: Sync changes instantly to the Employee dashboard using Socket.IO.

---

## Technical Flow

### 1. Data Ingestion
- When an order is created or updated, the `PriorityEngine` is triggered.
- It pulls: `deliveryDate`, `isRush`, `estimatedTime`, and `inventoryStatus`.

### 2. The Weighting Algorithm
The score is calculated as follows:
- **Urgency (40%)**: `(CurrentDate - OrderDate) / (DeliveryDate - OrderDate)`.
- **Rush Multiplier (30%)**: Flat 30-point boost if `isRush` is true.
- **Batch Optimization (20%)**: +20 points if the design matches the currently loaded machine setup.
- **Customer Tiers (10%)**: Potential for VIP customer prioritization.

### 3. Dashboard Integration
- **Backend**: `aiController.js` updates the `priorityScore` in the database.
- **Frontend**: The `Employee` dashboard fetches orders sorted by `priorityScore` DESC.
- **Real-time**: Socket.IO emits `queueUpdated`, forcing a re-sort on all active dashboards.

---

## Instructions for Implementation
1. **Schema Update**: Add `priorityScore` to the `Order` model in `schema.prisma`.
2. **Core Logic**: Create a helper function `calculatePriority(orderId)` in `utils/aiHelpers.js`.
3. **Worker Process**: Set up a background worker or hook in the `Order` controller to trigger recalculation for the entire active queue whenever a new order arrives.
