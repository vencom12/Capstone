# Implementation Plan: Multi-Machine Management & Production ERP

## Goal
To build a scalable infrastructure that allows the business to manage multiple embroidery machines, assign specific employees to those machines, and allocate inventory resources dynamically. This transforms the system into a professional production ERP (Enterprise Resource Planning) tool.

## Specific Goals
1. **Machine Lifecycle Management**: Create, Read, Update, and Delete (CRUD) hardware stations.
2. **Resource Allocation**: Assign specific inventory (e.g., thread colors) to specific machines.
3. **Staff Assignment**: Link employees to specific machines to track productivity and station health.
4. **AI Load Balancing**: Route incoming orders to the machine with the lowest current workload or best-suited capabilities.

---

## Technical Instructions

### 1. Database Schema (Prisma)
#### [NEW] Machine Model
```prisma
model Machine {
  id                String   @id @default(uuid())
  name              String   @unique
  model             String?
  status            String   @default("IDLE") // IDLE, RUNNING, MAINTENANCE, OFFLINE
  capabilities      String[] // e.g., ["Cap Embroidery", "Flat Bed", "T-Shirts"]
  
  // Resource Allocation
  allocatedMaterials Json?    // Tracking loaded thread colors/inventory IDs
  
  // Staff Assignment
  assignedEmployeeId String?
  assignedEmployee   User?    @relation(fields: [assignedEmployeeId], references: [id])
  
  // Production Link
  activeOrderId      String?
  activeOrder        Order?   @relation("MachineActiveOrder", fields: [activeOrderId], references: [id])
  
  createdAt          DateTime @default(now())
  updatedAt          DateTime @updatedAt
}
```

### 2. Backend Controllers
#### [NEW] machineController.js
- **`registerMachine`**: Initialize new hardware.
- **`assignStaff`**: Link a `userId` to a `machineId`.
- **`allocateResources`**: Update the `allocatedMaterials` JSON with current thread/material IDs.
- **`getProductionState`**: Aggregate all machines and their current statuses for the Admin dashboard.

### 3. Frontend UI Goals

#### Admin Dashboard (Production Tab)
- **Machine Grid**: A visual layout showing all machine cards.
- **Configuration Modal**: A form to change machine settings, allocated resources, and assigned staff.
- **Global Toggle**: Ability to put the entire line into "Maintenance Mode."

#### Employee Dashboard (Station Tab)
- **My Station**: A simplified view showing only the machine(s) assigned to the current user.
- **Status Controls**: Quick-access buttons for the employee to mark a machine as "Broken" or "Running."

---

## Verification Plan
1. **Hardware Registration**: Add a machine via the Admin panel and verify it appears in the database.
2. **Employee Sync**: Assign "Employee A" to "Machine 1" and verify that "Machine 1" appears on Employee A's dashboard but NOT on Employee B's.
3. **Resource Check**: Allocate "Red Thread (ID: 123)" to Machine 1 and verify the allocation persists after a dashboard refresh.
