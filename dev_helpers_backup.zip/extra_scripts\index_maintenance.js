require('dotenv').config();
const mongoose = require('mongoose');

async function checkIndexes() {
    try {
        await mongoose.connect(process.env.MONGODB_URI);
        console.log('Connected to MongoDB for index maintenance...');

        const collections = ['orders', 'transactions', 'users', 'products'];
        
        for (const colName of collections) {
            console.log(`\n--- ${colName.toUpperCase()} INDEXES ---`);
            const collection = mongoose.connection.db.collection(colName);
            const indexes = await collection.indexes();
            console.table(indexes.map(idx => ({
                Name: idx.name,
                Key: JSON.stringify(idx.key),
                Unique: !!idx.unique,
                Sparse: !!idx.sparse
            })));

            // Basic maintenance: Check for redundant indexes (e.g., if a compound index covers a single index)
            // This is just a diagnostic print in this stub
        }

        console.log('\n[OK] Index maintenance diagnostic complete.');
        process.exit(0);
    } catch (err) {
        console.error('Maintenance error:', err);
        process.exit(1);
    }
}

checkIndexes();
