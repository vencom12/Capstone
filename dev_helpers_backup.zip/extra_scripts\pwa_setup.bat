@echo off
set SRC="C:\Users\revin\.gemini\antigravity\brain\09a1cac5-80da-4d9a-82ad-a83648b9c570\app_icon_512_1774602914489.png"
set DEST="c:\Users\revin\Downloads\Capstone\icons\icon-512.png"
copy /Y %SRC% %DEST%
if %ERRORLEVEL% EQU 0 (
    echo Icon copied successfully.
) else (
    echo Failed to copy icon.
)
