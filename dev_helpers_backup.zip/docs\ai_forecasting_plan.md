# AI Feature Plan: Strategic Forecasting for Business Operations

## Goal
An "AI Business Advisor" that analyzes historical data, current traffic, and inventory levels to suggest optimal business tactics and implement them with admin approval.

## Specific Goals
1. **Demand Prediction**: Analyze `SiteTraffic` and `Order` history to predict upcoming busy periods.
2. **Inventory Optimization**: Suggest restocking specific materials before they run out based on order velocity.
3. **Dynamic Pricing Suggestions**: Recommend price adjustments for popular designs with high demand.
4. **Auto-Implementation**: Allow the Admin to click "Implement" on a suggestion (e.g., "Create a 10% discount for Design X to clear stock") to execute it instantly.

---

## Technical Flow

### 1. Data Aggregation
- Periodically scan `Order`, `SiteTraffic`, and `Inventory` tables.
- Calculate **Velocity**: `ItemsSold / TimePeriod`.
- Calculate **Conversion**: `Orders / SiteVisits`.

### 2. Suggestion Engine (LLM Integration)
- Send summarized data to an LLM (e.g., Groq/Llama-3).
- **Prompt**: "Based on this traffic increase and low stock of Gold thread, what should the Admin do?"
- **Output**: A structured JSON object containing a `reasoning`, a `suggestion`, and a `command` (e.g., `updatePrice`).

### 3. Execution Layer
- The Admin dashboard displays these suggestions as "Intelligence Reports."
- Each report has a "Permit Action" button.
- Clicking the button triggers the corresponding API endpoint to update pricing, create a discount, or send a restock reminder.

---

## Instructions for Implementation
1. **Analytics Engine**: Create `controllers/postgres/forecastingController.js`.
2. **Dashboard UI**: Build the "Stitch-Opt Intelligence Report" card in the Admin Overview.
3. **Command Patterns**: Define a set of "Auto-Actions" (Update Price, Create Promo, Toggle Rush) that the AI is allowed to trigger.
