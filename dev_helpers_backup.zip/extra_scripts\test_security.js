const fetch = require('node-fetch');

async function verifySecurity() {
    const baseUrl = 'http://localhost:5000/api/auth/register';
    const testUsers = [
        { username: 'hacker_admin', email: 'hacker@admin.com', password: 'password123', role: 'admin' },
        { username: 'hacker_employee', email: 'hacker@employee.com', password: 'password123', role: 'employee' }
    ];

    console.log('>>> SECURITY VERIFICATION START <<<');

    for (const user of testUsers) {
        console.log(`\nAttempting to register as ${user.role}...`);
        try {
            const response = await fetch(baseUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(user)
            });

            if (response.ok) {
                const data = await response.json();
                console.log(`Status: ${response.status} (OK)`);
                console.log(`Created Role: ${data.user.role}`);
                
                if (data.user.role === 'customer') {
                    console.log('✅ SUCCESS: Role was forced to customer.');
                } else {
                    console.log('❌ FAILURE: Role was NOT restricted!');
                }
            } else {
                const err = await response.json();
                console.log(`Status: ${response.status}`);
                console.log(`Message: ${err.message}`);
                console.log('✅ SUCCESS: Registration rejected or failed as expected.');
            }
        } catch (err) {
            console.error('Error:', err.message);
            console.log('Ensure the server is running on localhost:5000');
        }
    }
    console.log('\n>>> SECURITY VERIFICATION END <<<');
}

verifySecurity();
