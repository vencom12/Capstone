const mongoose = require('mongoose');
const uri = "mongodb://127.0.0.1:27017/test";
console.log("Testing connection to:", uri);
mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 })
  .then(() => {
    console.log("SUCCESS: Connected to MongoDB!");
    process.exit(0);
  })
  .catch(err => {
    console.error("FAILURE: Could not connect!", err.message);
    process.exit(1);
  });
