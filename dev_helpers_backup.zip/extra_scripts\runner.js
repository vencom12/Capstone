const { execSync } = require('child_process');
const fs = require('fs');
console.log("Starting server...");
execSync('start node server.js');
console.log("Server started. Waiting 2s...");
setTimeout(() => {
    console.log("Running registration fetch...");
    execSync('node test_reg.js');
    console.log("Done.");
    if(fs.existsSync('server_log.txt')) {
        console.log("Log contents:\n" + fs.readFileSync('server_log.txt', 'utf8'));
    } else {
        console.log("No log file found.");
    }
    process.exit(0);
}, 2000);
