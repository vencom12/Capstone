const fs = require('fs');
try {
    fs.writeFileSync('c:/Users/revin/Downloads/Capstone/debug_node.txt', 'Node is alive at ' + new Date());
    console.log('Success');
} catch (e) {
    fs.writeFileSync('c:/Users/revin/Downloads/Capstone/debug_node.txt', 'Error: ' + e.message);
}
