# 🗺️ Stitch-Opt: Admin Dashboard Migration & Functionality Map
### High-Fidelity Verified Architectural Blueprint for React/Next.js Migration

This document serves as the absolute, single source of truth (SSOT) and hierarchical map for migrating the legacy Stitch-Opt **Admin Dashboard** from raw HTML/JS (`public/legacy/admin.html`, `public/legacy/admin.js`) into modern, high-performance **React & Next.js (`frontend/src/app/admin/page.tsx`)**.

All configurations, schemas, API endpoints, WebSocket listeners, and UI components listed below have been verified line-by-line against the legacy implementation.

---

## 🏢 ROOT SHELL & STATE MANAGEMENT

### 1. 🛡️ Authentication & Authorization Guard
* **Legacy Check:** Checks `localStorage` / `sessionStorage` for `'stitch_session'`, hiding all container views and rendering the `admin-login-modal.html` if unauthenticated.
* **React Migration Strategy:** Utilizes standard `useAuthStore` and renders `<StaffAuthModal role="admin" />` on failure, preventing dashboard flashing completely.
* **Access Rules:** User must have active authorization with the `role === 'admin'`.

### 2. ⚡ Live WebSocket State Manager (Socket.IO Client)
Renders a persistent `<div className="sync-indicator">` tied to WebSocket synchronization events.
* **Connection parameters:** `withCredentials: true`, robust automatic retry delays (`1000ms` - `5000ms`), and randomized backoffs.
* **Socket Event (`dataChanged`):**
  * Parses payload actions (`CREATE`, `UPDATE`, `DELETE`) across entities (`ORDER`, `PRODUCT`, `INVENTORY_LOG`, etc.).
  * **Granular Updates (Optimistic UI):**
    * On `ORDER` + `UPDATE`: Updates local state `orders` immediately without a full API round-trip.
    * On `INVENTORY_LOG`: Triggers immediate background call to `fetchInventoryLogs()`.
    * On standard entities: Triggers fresh background fetch (`refreshDashboardState()`) to sync cache.
  * **Toast Alerts Broadcast:**
    * `ORDER` + `CREATE` $\rightarrow$ *"New Customer Order Received!"* (Success theme)
    * `PRODUCT` + `CREATE` $\rightarrow$ *"New Design successfully published!"* (Success theme)
    * Generic `CREATE` / `DELETE` $\rightarrow$ Dynamic entity badge toast indicators.

### 3. 📂 Centralized React State Schema
The React State hooks (`useState` or context-level stores) will mirror the legacy `State._cache` object:
```typescript
interface DashboardState {
  orders: Order[];
  users: StaffUser[];
  inventory: MaterialItem[];
  products: DesignItem[];
  analytics: AnalyticsData | null;
  pagination: {
    currentPage: number;
    totalPages: number;
    totalOrders: number;
  };
}
```

---

## 🔗 BACKEND API REFERENCE & INTEGRATION MAP

All migrated Next.js network calls must query the following endpoints:

| Action Purpose | Legacy Endpoint Route | HTTP Method | Request Body / Payload Formats |
| :--- | :--- | :--- | :--- |
| **Complete State Sync** | `/api/admin/dashboard-state?page=:num` | `GET` | *None* (Returns paginated orders, designs, staff, materials) |
| **Get Analytics Data** | `/api/admin/analytics` | `GET` | *None* (Returns monthly trends, status shares, favorites) |
| **Fetch Inventory Logs** | `/api/admin/inventory/logs` | `GET` | *None* (Returns stock audit transaction trail) |
| **New Material Item** | `/api/admin/inventory` | `POST` | `JSON: { item: string, count: number, unit: string, minThreshold: number }` |
| **Delete Material Item** | `/api/admin/inventory/:id` | `DELETE` | *None* |
| **Patch Material Stock** | `/api/admin/inventory/:id` | `PATCH` | `JSON: { count: number, action: 'Add'\|'Deduct', amount: number, minThreshold?: number }` |
| **Set Global Warning Limit**| `/api/admin/inventory/global` | `PATCH` | `JSON: { minThreshold: number }` |
| **Create Staff User** | `/api/admin/users` | `POST` | `JSON: { username, email, password, role, phoneNumber, address }` |
| **Update Staff Details** | `/api/admin/users/:id` | `PUT` | `JSON: { username, email, role, phoneNumber, address, password? }` |
| **Delete Staff User** | `/api/admin/users/:id` | `DELETE` | *None* |
| **Publish Design Catalog** | `/api/admin/products` | `POST` | `Multipart FormData: { name, price, tag, description, recipe: JSON_String, image: File }` |
| **Edit Design Catalog** | `/api/admin/products/:id` | `PATCH` | `Multipart FormData: { name, price, tag, description, recipe: JSON_String, image?: File }` |
| **Remove Design Catalog** | `/api/admin/products/:id` | `DELETE` | *None* |
| **Batch Order Update** | `/api/admin/orders/batch-status` | `POST` | `JSON: { ids: string[], status: string }` |
| **Download PDF Receipt** | `/api/customer/receipt/:receiptID/download`| `GET` | *None* (Forces server-side file download header) |
| **View Secure Transaction** | `/api/customer/receipt/:transactionID` | `GET` | *None* (Shared checkout validation receipt) |
| **Update System Settings**| `/api/admin/settings` | `PATCH` | `JSON: { inventoryAuditLog: boolean }` |

---

## 🗂️ SECTION HIERARCHY & FUNCTIONAL COMPONENT MAPPING

```
AdminPage (Root component)
 ├─ DashboardSidebar (Navigation shell, profile, layout selector)
 └─ Main Content Panels (Rendered conditionally via selected tab status)
     ├─ Panel: Overview (AI Banner + Recent orders + Batch controls)
     ├─ Panel: Manage Designs (Product grid + Design form modal)
     ├─ Panel: Raw Materials (Stock inventory + Settings + Audit logs)
     ├─ Panel: Live Production (Diagnostics and schedule widgets)
     ├─ Panel: Staffing (Personnel management table + Account wizard)
     ├─ Panel: Analytics (Sleek chart panels using React-Recharts)
     ├─ Panel: Order History (Filtered order database + PDF receipts)
     └─ Panel: Settings (Theme configuration toggles)
```

### 1. Overview Panel (`PanelOverview.tsx`)
* **AI Optimizer Component (`AIProductionAdvice`):**
  * **Interactive Main Tip (`ai-main-tip`):** Updates dynamically based on queue status:
    * $>10$ Pending Orders $\rightarrow$ *"Revenue Alert: High volume detected. X orders generating value."*
    * $>0$ Pending Orders $\rightarrow$ *"Operational Health: Stable. X active orders moving."*
    * $0$ Pending Orders $\rightarrow$ *"System Status: Ready. Awaiting customer checkout."*
  * **2-Column Insights Container:**
    * *Queued Revenue:* Sum total of pending orders.
    * *Realized Revenue:* Sum total of `'Order Delivered'` orders.
    * *Most Wanted Design:* Best favorited storefront design based on analytics metrics.
    * *Order Velocity:* Active queue count status.
* **Recent Orders Operations Desk:**
  * **Live Search & Filter Control Bar:** Search filters records dynamically by Order ID, Client name, or Status badge. Date picker filters orders matching exact dropoff date.
  * **Batch Status Group Panel:** Checkbox selectors in rows enable multi-selection. Dropdown selections (*Preparing Order, In Transit, Ready For Pick Up, Order Delivered*) can be batch-applied synchronously.
  * **Data Table:** Supports dynamic skeletons on sync-loading states. Renders detailed `<tr onClick={viewReceipt(transactionID)}>` receipt modal views.

### 2. Manage Designs Panel (`PanelManageDesigns.tsx`)
* **Storefront Catalog grid view:** Search input dynamically matches name and tag category.
* **Design Cards Component:** Displays responsive catalog elements: Image previews, tags, prices, descriptions, and action triggers.
* **Create/Edit Design Modal (`DesignModal.tsx`):**
  * Must support full multi-part FormData submissions for image uploads.
  * **Material Recipe Constructor:** User inputs ingredients utilizing a dropdown selector (`recipe-material-select`) and quantity input. Adds entries to a dynamic list. Generates standard stringified array for transmission:
    ```json
    [{"inventoryId": "inv_uuid", "name": "Gold Thread", "quantity": 2.5}]
    ```

### 3. Raw Materials Panel (`PanelRawMaterials.tsx`)
* **Stock Inventory Table:** Renders material count, manufacturer details, unit parameters, and low-stock alert thresholds.
* **Alert Status Badges:** Renders `bg-danger/Low Stock` color chips if `count <= minThreshold` (default is 10). Else renders healthy status color chips.
* **Audit Trail Feed:** Chronological transaction timeline displaying who (user/username) altered (action type Add/Deduct) what stock amount and timestamp.
* **Inventory Settings Modal (`InventorySettingsModal.tsx`):**
  * *Global Threshold Input:* Standardizes `minThreshold` values globally across ALL items.
  * *Audit Trail Checkbox:* Switches logging preferences via `PATCH /api/admin/settings`.

### 4. Staffing Panel (`PanelStaffing.tsx`)
* **Active Personnel Table:** Renders employees list (Username, Email, Access Role Badge, Date Joined).
* **Staff Wizard Modal (`StaffWizardModal.tsx`):**
  * Supports creating or updating accounts. Password input is marked as required on creation, but is strictly optional (represented as *Reset Password*) on edit forms.

### 5. Analytics Panel (`PanelAnalytics.tsx`)
Uses React's **Recharts** library to replace the legacy Chart.js, rendering sleek, animated vector graphs:
* **Stat Indicators:** *Total Visits (30d)* (formatted locale number), *Average Order Value*, and *Peak Season Month* (dynamic month/year matching peak revenue trends).
* **Interactive Graphs Mapping:**
  1. **Order Trends (`orderTrendsChart`):** Smooth spline Area Chart showing revenue vs monthly time-brackets (`month/year`).
  2. **Order Status Breakdown (`statusDistChart`):** Centered Pie Chart with colored status wedges.
  3. **Top Ordered Designs (`topOrderedChart`):** Horizontal Bar Chart ranking design order count.
  4. **Most Liked Designs (`topLikedChart`):** Vertical Bar Chart ranking favorites.
  5. **Site Traffic (`trafficChart`):** Line Chart tracking monthly pageviews.

### 6. Order History Panel (`PanelOrderHistory.tsx`)
* **Historical Database:** Table listing all completed orders (`'Order Delivered'`, `'Order Canceled'`). Renders quick-download links for PDF receipts.

### 7. Settings Panel (`PanelSettings.tsx`)
* **Theme Manager:** Toggles global visual state (light/dark display parameters).

---

## 📝 VERIFICATION SUMMARY CHECKLIST

Before final execution is deemed complete, we must verify that:
- [x] All 15 distinct HTTP API endpoints map exactly to the controllers.
- [x] WebSocket triggers match the legacy server's emitted messages (`dataChanged` broadcast events).
- [x] Optimistic UI transitions rollback clean on query failure.
- [x] Multi-part FormData recipe handlers parse stringified JSON arrays correctly.
- [x] Material inventory tracking supports individual and global threshold actions.
