# AI Feature Plan: Payment Verification Automation

## Goal
To eliminate manual receipt checking by using AI Vision to automatically verify customer payment screenshots and activate order processing.

## Specific Goals
1. **OCR Extraction**: Automatically read Transaction IDs, Amounts, and Dates from GCash, Maya, and Bank receipts.
2. **Database Cross-Referencing**: Match the extracted data against the expected `Order` amount and status.
3. **Fraud Prevention**: Detect duplicate receipts or altered images using metadata and confidence scores.
4. **Auto-Transition**: Move orders from "Pending Payment" to "Processing" immediately upon successful verification.

---

## Technical Flow

### 1. Image Upload
- Customer uploads a receipt via the `checkout-modal`.
- The image is stored temporarily (or in Cloudinary).

### 2. Vision Analysis (Groq Llama 3.2 Vision)
- The image URL is sent to the Vision API.
- **Prompt**: "Extract the transaction number, total amount, and date from this receipt."
- The AI returns structured JSON data.

### 3. Verification Logic
- **Amount Check**: Does `extractedAmount == order.totalAmount`?
- **Duplicate Check**: Has this `transactionID` already been used in the `Transaction` table?
- **Status Update**: If everything matches, the AI triggers `prisma.order.update({ where: { id: orderId }, data: { status: 'Processing' } })`.

---

## Instructions for Implementation
1. **API Setup**: Refine `controllers/postgres/aiController.js` to handle the Vision response.
2. **UI Feedback**: Add a "Verifying Payment..." loading state in the customer storefront.
3. **Human Fallback**: If the AI confidence score is low (< 0.85), flag the receipt for manual Admin review instead of auto-processing.
