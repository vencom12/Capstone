const fs = require('fs');
const path = require('path');

const src = 'C:\\Users\\revin\\.gemini\\antigravity\\brain\\09a1cac5-80da-4d9a-82ad-a83648b9c570\\app_icon_512_1774602914489.png';
const dest512 = 'c:\\Users\\revin\\Downloads\\Capstone\\icons\\icon-512.png';
const dest192 = 'c:\\Users\\revin\\Downloads\\Capstone\\icons\\icon-192.png';

try {
    fs.copyFileSync(src, dest512);
    fs.copyFileSync(src, dest192);
    console.log('Icons copied successfully.');
} catch (e) {
    console.error('Error copying icons:', e.message);
}
