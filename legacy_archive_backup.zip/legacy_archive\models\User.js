const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true, index: true },
    email: { type: String, required: true, unique: true, index: true },
    password: { type: String, required: true, minlength: 8 },
    role: { type: String, enum: ['admin', 'employee', 'customer'], default: 'customer' },
    walletBalance: { type: Number, default: 0 },
    favorites: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Product' }],
    phoneNumber: { type: String, required: function() { return this.role === 'customer'; } },
    address: { type: String, required: function() { return this.role === 'customer'; } },
    createdAt: { type: Date, default: Date.now, index: true }
});

// Hash password before saving
userSchema.pre('save', async function(next) {
    if (!this.isModified('password')) return next();
    this.password = await bcrypt.hash(this.password, 10);
    next();
});

// Helper for password validation
userSchema.methods.comparePassword = async function(candidatePassword) {
    return await bcrypt.compare(candidatePassword, this.password);
};

module.exports = mongoose.model('User', userSchema);
